import { Component } from '@angular/core';

@Component({
  selector: 'app-online-tutoring',
  templateUrl: './online-tutoring.component.html',
  styleUrls: ['./online-tutoring.component.css']
})
export class OnlineTutoringComponent {

}
