import { Component } from '@angular/core';

@Component({
  selector: 'app-enroll-now',
  templateUrl: './enroll-now.component.html',
  styleUrls: ['./enroll-now.component.css']
})
export class EnrollNowComponent {

}
